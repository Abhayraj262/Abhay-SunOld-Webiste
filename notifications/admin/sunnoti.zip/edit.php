<?php include('db.php'); 

if( isset($_GET['id']) ){

    $id = $_GET['id'];

}else{

    header("location:index.php");
    exit;
}

if (isset($_POST['update'])) {
    
    $title = $_POST['title'];
    $keywords = $_POST['keywords'];
    $description = addslashes($_POST['description']);
    $og_url = $_POST['og_url'];
    $og_site_name = $_POST['og_site_name'];
    $og_title = $_POST['og_title'];
    $og_description = addslashes($_POST['og_description']);
    $twitter_card = $_POST['twitter_card'];
    $twitter_site = $_POST['twitter_site'];
    $twitter_title = $_POST['twitter_title'];
    $twitter_description = addslashes($_POST['twitter_description']);    
    $main_heading = $_POST['main_heading'];
    $main_description = addslashes($_POST['main_description']);
    $path = $_POST['path'];
    $pdf_link = $_POST['pdf_link'];
    $status = $_POST['status'];
    $publish_date = date('Y-m-d', strtotime($_POST['publish_date']));

    $qry = "";
    if(  isset($_FILES['twitter_image']['name']) ){

        // banner upload code  
        $twitter_image= $_FILES['twitter_image']['name'];	
        $tmpp = $_FILES['twitter_image']['tmp_name'];
        
        if( $twitter_image ){
            
            $page_thumbimage = time().str_replace(" ","_",@basename($twitter_image));
            $target_path_original="uploads/";					
            $target_path_original = $target_path_original.$page_thumbimage;					
            move_uploaded_file($tmpp,$target_path_original);		
            
            $twitter_image = $page_thumbimage;
            $qry = "twitter_image='$twitter_image',";
        }
    }

    $sql = "update notifications set
        title='$title', 
        keywords='$keywords',
        description='$description',
        og_url='$og_url',
        og_site_name='$og_site_name',
        og_title='$og_title',
        og_description='$og_description',
        twitter_card='$twitter_card',
        twitter_site='$twitter_site',
        twitter_title='$twitter_title',
        twitter_description='$twitter_description',
        $qry
        main_heading='$main_heading',
        main_description='$main_description',
        path='$path',
        pdf_link='$pdf_link',
        status='$status',
        publish_date='$publish_date' where id=$id";

        //echo $sql;

    if ($conn->query($sql) === TRUE) {
        echo "Post updated successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$sql = "SELECT * FROM notifications WHERE id = $id";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

// echo "<pre>";
// print_r($row);

?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Post</title>
    <link href="css/custom.css" rel="stylesheet">

    <!-- flatpickr CSS and javascript -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <!--CKEditor CKFinder js-->
    <script type="text/javascript" src="ckeditor/ckeditor.js"></script>
</head>
<body>

<h2>Edit Post</h2>

<form method="POST" enctype="multipart/form-data">
        <label for="title">Title:</label>
        <input type="text" name="title" value="<?php echo $row['title'];?>" value=" <?php echo $row['title'];?>" required><br><br>
        <label for="title">keywords:</label>
        <input type="text" name="keywords" value="<?php echo $row['keywords'];?>" required><br><br>
        <label for="title">Description:</label>
        <textarea name="description" id="description" rows="10" cols="50"><?php echo stripslashes($row['description']);?></textarea>
        <script type="text/javascript">
            var editor = CKEDITOR.replace( 'description', {

                filebrowserBrowseUrl : 'ckfinder/ckfinder.html',

                filebrowserImageBrowseUrl : 'ckfinder/ckfinder.html?type=Images',

                filebrowserFlashBrowseUrl : 'ckfinder/ckfinder.html?type=Flash',

                filebrowserUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',

                filebrowserImageUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',

                filebrowserFlashUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash'

            });

            CKFinder.setupCKEditor( editor, '../' );

        </script><br><br>
        <label for="title">OG url:</label>
        <input type="text" name="og_url" value="<?php echo $row['og_url'];?>" required><br><br>
        <label for="title">OG Site Name:</label>
        <input type="text" name="og_site_name" value="<?php echo $row['og_site_name'];?>" required><br><br>
        <label for="title">OG Title:</label>
        <input type="text" name="og_title" value="<?php echo $row['og_title'];?>" required><br><br>
        <label for="title">OG Description:</label>
        <textarea name="og_description" id="og_description" rows="10" cols="50"><?php echo stripslashes($row['og_description']);?></textarea>
        <script type="text/javascript">
            var editor = CKEDITOR.replace( 'og_description', {

                filebrowserBrowseUrl : 'ckfinder/ckfinder.html',

                filebrowserImageBrowseUrl : 'ckfinder/ckfinder.html?type=Images',

                filebrowserFlashBrowseUrl : 'ckfinder/ckfinder.html?type=Flash',

                filebrowserUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',

                filebrowserImageUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',

                filebrowserFlashUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash'

            });

            CKFinder.setupCKEditor( editor, '../' );

        </script><br><br>
        <label for="title">Twitter Card:</label>
        <input type="text" name="twitter_card" value="<?php echo $row['twitter_card'];?>" required><br><br>
        <label for="title">Twitter Site:</label>
        <input type="text" name="twitter_site" value="<?php echo $row['twitter_site'];?>" required><br><br>
        <label for="title">Twitter Title:</label>
        <input type="text" name="twitter_title" value="<?php echo $row['twitter_title'];?>" required><br><br>
        <label for="title">Twitter Description:</label>
        <textarea name="twitter_description" id="twitter_description" rows="10" cols="50"><?php echo stripslashes($row['twitter_description']);?></textarea>
        <script type="text/javascript">
            var editor = CKEDITOR.replace( 'twitter_description', {

                filebrowserBrowseUrl : 'ckfinder/ckfinder.html',

                filebrowserImageBrowseUrl : 'ckfinder/ckfinder.html?type=Images',

                filebrowserFlashBrowseUrl : 'ckfinder/ckfinder.html?type=Flash',

                filebrowserUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',

                filebrowserImageUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',

                filebrowserFlashUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash'

            });

            CKFinder.setupCKEditor( editor, '../' );

        </script><br><br>
        <label for="title">Twitter Image:</label>
        <input type="file" name="twitter_image" accept=".png, .jpg, .jpeg .webp" ><br><br>
            <?php 
      
               if( $row['twitter_image'] and file_exists(__DIR__."/uploads/".$row['twitter_image']) ){

                    echo '<img src="uploads/'.$row['twitter_image'].'" width="200">';
               } 
            ?>
        <br><br>
        <label for="title">Main Heading:</label>
        <input type="text" name="main_heading" value="<?php echo $row['main_heading'];?>" required><br><br>
        <label for="title">Main Description:</label>
        <textarea name="main_description" id="main_description" rows="10" cols="50"><?php echo stripslashes($row['main_description']);?></textarea>
        <script type="text/javascript">
            var editor = CKEDITOR.replace( 'main_description', {

                filebrowserBrowseUrl : 'ckfinder/ckfinder.html',

                filebrowserImageBrowseUrl : 'ckfinder/ckfinder.html?type=Images',

                filebrowserFlashBrowseUrl : 'ckfinder/ckfinder.html?type=Flash',

                filebrowserUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',

                filebrowserImageUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',

                filebrowserFlashUploadUrl : 'ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash'

            });

            CKFinder.setupCKEditor( editor, '../' );

        </script><br><br>
        <label for="title">Path:</label>
        <input type="text" name="path" value="<?php echo $row['path'];?>" required><br><br>
        <label for="title">PDF Link:</label>
        <input type="text" name="pdf_link" value="<?php echo $row['pdf_link'];?>" required><br><br>
        <label for="title">status:</label>
        <label class="switch">
            <input <?php if( $row['status'] == 1 ) {echo "checked"; echo ' value="1"';}?> type="checkbox" name="status" >
            <span class="slider round"></span>
        </label><br><br>  
        <label for="title">Publish Date:</label>
        <input type="text" class="datepicker" name="publish_date" value="<?php echo date('d-m-Y', strtotime($row['publish_date']));?>" required><br><br>    
        
        <br><br><button type="submit" name="update">Update Post</button>
    </form>

<script>
$(function(){
       //publish/unpublish
       jQuery(".slider.round").click(function() {

            if (jQuery("input[name='status']").is(":checked") == true) {

                jQuery("input[name='status']").val(0);
            } else {

                jQuery("input[name='status']").val(1);
            }
        }); 

        flatpickr('.datepicker', {						
            // put options here if your don't want to add them via data- attributes
                //enableTime: true,
                dateFormat: "d-m-Y"				
		});


});
</script>
</body>
</html>

<div class="mail-list text-center"><span style="margin-inline:1px;color: rgb(255, 255, 255);">info@sunconsultants.co.in | Mob: +91-9315973373, 7303745057</span>
</div>
<div class="container-fluid bg-reda">
  <div class="site-navigation">
    <div class="container">
      <div class="col-sm-12">
        <div class="row">
          <div class="col-lg-12 col-sm-12">
            <nav class="navbar navbar-expand-lg navbar-dark p-0">
              <button class="navbar-toggler" type="button" data-toggle="collapse" data-target=".navbar-collapse" aria-controls="navbar-collapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <span><a href="/"><img src="img/logo/ll.webp" class="logo-img" alt="logo"></a></span>

              <div id="navbar-collapse" class="collapse navbar-collapse">

                <ul class="nav navbar-nav mr-auto">
                  <li class="nav-item"><a class="nav-link" href="/"></a></li>
                  <li class="nav-item"><a class="nav-link" href="/"></a></li>
                  <li class="nav-item"><a class="nav-link" href="/"></a></li>
                  <li class="nav-item active"><a class="nav-link" href="/">HOME</a></li>

                  <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle " data-toggle="dropdown">ABOUT US <i class="fa fa-angle-down"></i></a>
                    <ul class="dropdown-menu" role="menu">

                      <li><a href="gallery">Audits and Exhibitions Gallery</a></li>
                      <li><a href="our-clients">OUR CLIENTS</a></li>


                    </ul>
                  </li>
                  <li class="nav-item dropdown">
                    <a href="" class="nav-link dropdown-toggle" data-toggle="dropdown">SERVICES<i class="fa fa-angle-down"></i></a>

                    <ul class="dropdown-menu" role="menu" style="width: 700px !important;">
                      <div class="row">

                        <div class="col-sm-4">
                          <ul type="none">
                            <li><a href="erp-certification-consultants">EPR</a></li>
                            <li><a href="lmpc-certification-consultants">LMPC</a></li>
                            <li><a href="tec-certification-consultants">TEC</a></li>
                            <li><a href="wpc-certification-consultants">WPC</a></li>
                            <li><a href="rohs-certification-consultants">ROHS</a></li>
                            <li><a href="bee-registration-certification">BEE</a></li>
                            <li><a href="ce-certification-consultants">CE CERTIFICATION</a></li>
                            <li><a href="legal-metrology-certification-consultants">LEGAL METROLOGY</a></li>
                            <li><a href="peso-certification-consultants">PESO APPROVAL</a></li>
                            <li><a href="emi-emc-certification-consultants">EMI/EMC</a></li>
                            <li><a href="cb-certification-consultants">CB CERTIFICATION</a></li>
                            <li><a href="plastic-waste-management-registration">Plastic Waste Management</a></li>
                          </ul>
                        </div>
                        <div class="col-sm-4">
                          <ul type="none">
                            <!-- 2end-colums -->

                            <li><a href="fmcs-certification-consultants">FMCS</a></li>
                            <li><a href="isi-mark-registration-certification">ISI MARK</a></li>
                            <li><a href="bis-registration-certification">BIS Certification</a></li>
                            <li><a href="bis-crs-registration">CRS</a></li>
                          </ul>
                        </div>
                        <div class="col-sm-4">
                          <ul type="none">
                            <li><a href="cdsco">CDSCO</a></li>
                          </ul>
                        </div>
                      </div>
                    </ul>
                  </li>
                  <li class="nav-item dropdown">
                    <a href="" class="nav-link dropdown-toggle" data-toggle="dropdown">FAQ'S<i class="fa fa-angle-down"></i></a>
                    <ul class="dropdown-menu" role="menu">
                      <li><a href="bis-licence-consultants">BIS Licence</a></li>
                      <li><a href="under">BIS Registration </a></li>
                      <li><a href="under">CDSCO Licence </a></li>
                      <li><a href="under">CDSCO Registration </a></li>
                      <!-- <li><a href="lmpc-1">LMPC </a></li> -->
                      <li><a href="under">Foreign Manufacturer BIS </a></li>
                    </ul>
                  </li>
                  <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle " data-toggle="dropdown">Updates <i class="fa fa-angle-down"></i></a>
                    <ul class="dropdown-menu" role="menu">

                      <li><a href="/latest-notifications">Latest Notifications</a></li>
                      <li><a href="/">News and Updates </a></li>
                      <li><a href="/">Blogs</a></li>

                    </ul>
                  </li>

                  <li class="nav-item"><a class="nav-link" href="contact-us">CONTACT US</a></li>
                  <li class="nav-item dropdown">
                    <a href="" class="nav-link dropdown-toggle" data-toggle="dropdown">MORE <i class="fa fa-angle-down"></i></a>
                    <ul class="dropdown-menu" role="menu">
                      <li><a href="/under">QUICK-PAY</a></li>

                    </ul>
                  </li>
                </ul>
              </div>
            </nav>
          </div>
          <!--/ Col end -->
        </div>
        <!--/ Row end -->
      </div>
      <!--/ Container end -->

    </div>
    <!--/ Navigation end -->
  </div>
</div>
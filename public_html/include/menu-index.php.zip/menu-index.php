<!--<div class="mail-list text-center alloff"><span style="margin-inline:1px;color: rgb(255, 255, 255);">-->
<!--    info@sunconsultants.co.in | Mob: +91-9958575407, 9315973373</span>-->
<!--</div>-->
<!--<div class="container-fluid bg-reda">-->
<!--  <div class="site-navigation">-->
<!--    <div class="container-fluid">-->
      <!-- <div class="col-sm-12"> -->
<!--      <div class="row">-->
<!--        <div class="col-lg-12 col-sm-12">-->
<!--          <nav class="navbar navbar-expand-lg navbar-dark margin">-->
<!--            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target=".navbar-collapse" aria-controls="navbar-collapse" aria-expanded="false" aria-label="Toggle navigation">-->
<!--              <span class="navbar-toggler-icon"></span>-->
<!--            </button>-->
<!--            <span class="lolo">-->
<!--              <a href="/">-->
<!--              <img src="img/logo/ll.webp" alt="sunconsultants logo" style="position: relative;height: 76px;" alt="logo"></a></span>-->
<!--            <div id="navbar-collapse" class="collapse navbar-collapse">-->
<!--              <a href="/"><img src="img/logo/ll.webp" class="lolu" alt="Sun Consultants"></a>-->
<!--              <ul class="nav navbar-nav mr-auto ">-->
<!--                <li class="nav-item"><a class="nav-link" href="/"></a></li>-->
<!--                <li class="nav-item"><a class="nav-link" href="/"></a></li>-->
<!--                <li class="nav-item"><a class="nav-link" href="/"></a></li>-->
<!--                <li class="nav-item active"><a class="nav-link" href="/">HOME</a></li>-->

<!--                <li class="nav-item dropdown">-->
<!--                  <a class="nav-link dropdown-toggle " data-toggle="dropdown">ABOUT US <i class="fa fa-angle-down"></i></a>-->
<!--                  <ul class="dropdown-menu" role="menu">-->

<!--                    <li><a href="gallery">Audits and Exhibitions Gallery</a></li>-->
<!--                    <li><a href="our-clients">OUR CLIENTS</a></li>-->


<!--                  </ul>-->
<!--                </li>-->
<!--                <li class="nav-item dropdown">-->
<!--                  <a href="" class="nav-link dropdown-toggle" data-toggle="dropdown">SERVICES<i class="fa fa-angle-down"></i></a>-->

<!--                  <ul class="dropdown-menu" role="menu" style="width: 820px !important; ">-->
<!--                    <div class="row">-->

<!--                      <div class="col-sm-4">-->
<!--                        <ul type="none">-->
<!--                          <li> <i class="fa fa-angle-right" style="-->
<!--                            font-size: 14px;-->
<!--                            color: #fff;"></i><a href="cdsco-registration-certification" style="margin-top: -32px;">CDSCO Registration</a></li>-->
<!--                          <li><i class="fa fa-angle-right" style="-->
<!--                            font-size: 14px;-->
<!--                            color: #fff;"></i><a href="fmcs-certification-consultants" style="margin-top: -32px;">BIS Mark (ISI license) for <br> Foreign Manufactures </a></li>-->
<!--                          <li><i class="fa fa-angle-right"style="-->
<!--                            font-size: 14px;-->
<!--                            color: #fff;"></i><a href="isi-mark-registration-certification"style="margin-top: -32px;">ISI MARK (BIS) for Indian Manufacturers </a></li>-->
<!--                          <li><i class="fa fa-angle-right"style="-->
<!--                            font-size: 14px;-->
<!--                            color: #fff;"></i><a href="epr-certification-consultants" style="margin-top: -32px;">EPR Registration </a></li>-->
<!--                          <li><i class="fa fa-angle-right"style="-->
<!--                            font-size: 14px;-->
<!--                            color: #fff;"></i><a href="lmpc-certification-consultants" style="margin-top: -32px;">LMPC Regitration </a></li>-->
                          
<!--                         <li><i class="fa fa-angle-right"style="margin-top:14px;-->
<!--                            font-size: 14px;-->
<!--                            color: #fff;"></i><a href="plastic-waste-management-registration" style="margin-top: -32px;">Plastic Waste Management </a></li>-->
                       
                        
<!--                        </ul>-->
                        
<!--                      </div>-->
<!--                      <div class="col-sm-4">-->
<!--                        <ul type="none">-->
                          <!-- 2end-colums -->

<!--                             <li><i class="fa fa-angle-right"style="-->
<!--                              font-size: 14px;-->
<!--                              color: #fff; margin-top:14px"></i><a href="legal-metrology-certification-consultants" style="margin-top: -33px;">LEGAL METROLOGY</a></li>-->
<!--                          <li><i class="fa fa-angle-right"style="-->
<!--                            font-size: 14px;-->
<!--                            color: #fff; margin-top:14px"></i><a href="bis-registration-certification" style="margin-top: -34px;">BIS Certification</a></li>-->
<!--                          <li><i class="fa fa-angle-right"style="-->
<!--                            font-size: 14px;-->
<!--                            color: #fff; margin-top:20px"></i><a href="bis-(crs)-registration-for-elect" style="margin-top: -30px;">CRS Registration (BIS)</a></li>-->
<!--                          <li><i class="fa fa-angle-right"style="-->
<!--                            font-size: 14px;-->
<!--                            color: #fff; margin-top:20px"></i><a href="peso-certification-consultants"style="margin-top: -30px;">PESO APPROVAL</a></li>-->
<!--                          <li><i class="fa fa-angle-right"style="-->
<!--                            font-size: 14px;-->
<!--                            color: #fff; margin-top:20px"></i><a href="tec-certification-consultants"style="margin-top: -30px;">TEC</a></li>-->
                          

                         
<!--                        </ul>-->
<!--                      </div>-->
<!--                      <div class="col-sm-4">-->
<!--                        <ul type="none">-->
                         
<!--                          <li><i class="fa fa-angle-right"style="-->
<!--                            font-size: 14px;-->
<!--                            color: #fff; margin-top:11px"></i><a href="wpc-certification-consultants" style="margin-top: -32px;">WPC</a></li>-->
<!--                          <li><i class="fa fa-angle-right"style="-->
<!--                            font-size: 14px;-->
<!--                            color: #fff; margin-top:10px"></i><a href="rohs-certification-consultants"style="margin-top: -32px;">ROHS</a></li>-->
<!--                          <li><i class="fa fa-angle-right"style="-->
<!--                            font-size: 14px;-->
<!--                            color: #fff; margin-top:10px"></i><a href="bee-registration-certification" style="margin-top: -32px;">BEE</a></li>-->
<!--                          <li><i class="fa fa-angle-right"style="-->
<!--                            font-size: 14px;-->
<!--                            color: #fff; margin-top:10px"></i><a href="ce-certification-consultants" style="margin-top: -32px;">CE CERTIFICATION</a></li>-->
                         
                          
<!--                          <li><i class="fa fa-angle-right"style="-->
<!--                            font-size: 14px;-->
<!--                            color: #fff; margin-top:10px"></i><a href="emi-emc-certification-consultants"style="margin-top: -32px;">EMI/EMC</a></li>-->
<!--                          <li><i class="fa fa-angle-right"style="-->
<!--                            font-size: 14px;-->
<!--                            color: #fff; margin-top:10px"></i><a href="cb-certification-consultants"style="margin-top: -32px;">CB CERTIFICATION</a></li>-->
                          
<!--                        </ul>-->
                        
<!--                      </div>-->
<!--                    </div>-->
<!--                  </ul>-->
<!--                </li>-->

<!--                <li class="nav-item dropdown">-->
<!--                  <a href="" class="nav-link dropdown-toggle" data-toggle="dropdown">FAQ'S<i class="fa fa-angle-down"></i></a>-->
<!--                  <ul class="dropdown-menu" role="menu">-->
<!--                    <li><a href="bis-licence-consultants">BIS Licence</a></li>-->
<!--                    <li><a href="under">BIS Registration </a></li>-->
<!--                    <li><a href="under">CDSCO Licence </a></li>-->
<!--                    <li><a href="cdsco-registration-certification">CDSCO Registration </a></li>-->
<!--                    <li><a href="under">Foreign Manufacturer BIS </a></li>-->
<!--                  </ul>-->
<!--                </li>-->
<!--                <li class="nav-item dropdown">-->
<!--                  <a class="nav-link dropdown-toggle " data-toggle="dropdown">Updates <i class="fa fa-angle-down"></i></a>-->
<!--                  <ul class="dropdown-menu" role="menu">-->

<!--                    <li><a href="latest-notifications">Latest Notifications</a></li>-->
<!--                    <li><a href="/">News and Updates </a></li>-->
<!--                    <li><a href="/">Blogs</a></li>-->

<!--                  </ul>-->
<!--                </li>-->
<!--                <li class="nav-item"><a class="nav-link" href="contact-us">CONTACT US</a></li>-->
<!--                <li class="nav-item dropdown">-->
<!--                  <a href="" class="nav-link dropdown-toggle" data-toggle="dropdown">MORE <i class="fa fa-angle-down"></i></a>-->
<!--                  <ul class="dropdown-menu" role="menu">-->
<!--                    <li><a href="/under">QUICK-PAY</a></li>-->

<!--                  </ul>-->
<!--                </li>-->
<!--              </ul>-->
<!--            </div>-->
<!--          </nav>-->
<!--        </div>-->
        <!--/ Col end -->
        <!-- </div> -->
        <!--/ Row end -->
<!--      </div>-->
      <!--/ Container end -->

<!--    </div>-->
    <!--/ Navigation end -->
<!--  </div>-->
<!--</div>-->



<!--<style>-->

<!--  .dropdown-menu li a {-->
<!--    display: block !important;-->
<!--    font-size: 14px !important;-->
<!--    text-transform: uppercase !important;-->
<!--    font-weight: 400 !important;-->
<!--    line-height: normal !important;-->
<!--    text-decoration: none !important;-->
<!--    padding: 10px 25px !important;-->
<!--    letter-spacing: 0.3px !important;-->
<!--    color: -->
<!--    #aaa !important;-->
<!--}--><!--</style>-->


<!DOCTYPE html>
<html lang="en">

<head>

     <!-- SEO Meta Codes ================================================== -->
     <meta charSet="utf-8" />
     <title itemprop="name"> CDSCO Registration Certificate Online - Sunconsultants</title>
     <meta name="keywords" content="BIS Certification, BIS Registration, BIS Certificate For Import, BIS Certification Cost, BIS Registration Online, BIS Certificate Online, BIS New Registration, BIS Agent, BIS Product Certification, Apply For BIS Certification, BIS Certificate Fees, BIS Certification Apply Online, BIS Certification Fees, BIS Registration Certificate, BIS Certificate Registration, BIS Online Registration" />
     <meta name="description" itemprop="description" content="BIS stands for Bureau of Indian Standards, an Indian National Standard Body established under the BIS Act of 2016. It was created to facilitate the establishment of product standardization, marking, quality certification, and incidental or related issues." />
     <meta name="viewport" content="width=device-width, initial-scale=1" />
     <meta name="author" content="Sun Consultants & Engineers" />
     <meta property="og:url" content="https://sunconsultants.co.in/bis-certification" />
     <meta property="og:site_name" content="Sun Consultants &amp; Engineers" />
     <meta property="og:title" content="BIS Certification | BIS stands for Bureau of Indian Standards" />
     <meta property="og:description" content="Ready for BIS Certification. Get BIS certificate with the assistance of our experts. Apply for BIS certificate today." />
     <meta property="og:type" content="website page" />
     <meta property="og:site_name" content="Legal Metrology Certification" />
     <meta property="og:image" content="https://sunconsultants.co.in/img/isi-msrk-img/LMPC-11.jpga" />
     <meta property="og:locale" content="en_IN" />
     <meta name="twitter:card" content="summary" />
     <meta name="twitter:site" content="@ConsultantsSun" />
     <meta name="twitter:title" content="BIS Certification | BIS stands for Bureau of Indian Standards" />
     <meta name="twitter:description" content="Ready for BIS Certification. Get BIS certificate with the assistance of our experts. Apply for BIS certificate today." />
     <meta name="twitter:image" content="https://sunconsultants.co.in/img/isi-msrk-img/LMPC-11.jpg" />
     <meta name="twitter:image:alt" content="LMPC Certification" />
     <meta name="robots" content="index, follow">




 
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>sunconsultants</title>
  <meta content="" name="description">

  <meta content="" name="keywords">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- Favicons -->
  <link href="assets/img/ll.web" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Raleway:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">
  <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->
  <!-- Vendor CSS Files -->
   <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
 <!-- <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet"> -->

  <!-- Template Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Impact
  * Updated: Mar 10 2023 with Bootstrap v5.2.3
  * Template URL: https://bootstrapmade.com/impact-bootstrap-business-website-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->

     <!-- Google tag (gtag.js) Google Analytics tracking-->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-163953232-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-163953232-1');
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [{
    "@type": "Question",
    "name": "How can I get BIS Certificate for an Overseas Manufacturer?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Fill out the regular application form first, and then attach all required paperwork. The next step is to designate an AIR—an authorized Indian representative—using the standard nomination form. Finally, submit these documents and the customary charge to the BIS headquarters in New Delhi."
    }
  },{
    "@type": "Question",
    "name": "Who Requires BIS Certificate?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Manufacturing Units effectively receive BIS Registration Certificates. But eligible goods importers and traders can also obtain this certification on behalf of their specific Manufacturing Units."
    }
  },{
    "@type": "Question",
    "name": "Validity of BIS Certification",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Two years."
    }
  }]
}
</script>
</head>

<body>

  <section id="topbar" class="topbar">
    <div class="container d-flex justify-content-center">
        <div class="mail-list text-center "><span style="margin-1px;color: rgb(255, 255, 255);">
            info@sunconsultants.co.in | Mob: +91-9315973373, 7303745057</span>
        </div>
   
      <div class="social-links d-none d-md-flex">
      
    <div class="d-flex justify-content-end ">
        <a href="https://api.whatsapp.com/send?phone=9315973373" class="whatsapp"><i class="bi bi-whatsapp"></i></i></a>
        <a href="tel:+91-9315973373" class="Phone"><i class="bi bi-telephone-forward-fill"></i></a>
        <span ></span>
      </div>
    </div>
  </section><!-- End Top Bar -->

  <header id="header" class="header d-flex align-items-center">

    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">
      <a href="index.html" class="logo d-flex align-items-center">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="assets/img/logo.png" alt=""> -->
       <div class="logo">
        <!-- <h3 style="font-weight: 700;
        margin-top: 7px;
        font-size: 33px;">Sun Consultants</h3> -->
       

       <img src="assets/img/suncons.png" alt="logo"  style="height: 85px !important;margin-top: 9px !important;">

       </div>
      </a>
     <nav id="navbar" class="navbar">
        <ul>
          <li><a href="/">HOME</a></li>
          <li class="dropdown"><a href="#"><span>ABOUT US</span> <i class="bi bi-chevron-down dropdown-indicator"></i></a>
            <ul style="width: 350px;">
              <li><i class="fa fa-angle-right" style="font-size:20px; margin-left: 10px;"></i>
              <a href="https://sunconsultants.co.in" style="margin-top: -35px;
                margin-left: 10px;">Audits and Exhibitions Gallery</a></li>
                <li><i class="fa fa-angle-right" style="font-size:20px; margin-left: 10px;"></i>
              <a href="https://sunconsultants.co.in" style="margin-top: -35px;
                margin-left: 10px;">Audits and Exhibitions Gallery</a></li>
              <li>
                  <i class="fa fa-angle-right" style="font-size:20px; margin-left: 10px;"></i><a href="https://sunconsultants.co.in/our-clients" style="margin-top: -35px;
                margin-left: 10px;">OUR CLIENTS</a></li>
              </ul>
         </li>

         

         

          <li class="dropdown megamenu"><a href="#"><span>SERVICES</span> <i class="bi bi-chevron-down dropdown-indicator"></i></a>
            <ul >
              <li>
                <i class="fa fa-angle-right" style="font-size:20px; margin-left: 10px;margin-top: 20px;"></i><a href="https://sunconsultants.co.in/cdsco-registration-certification" style="    margin-top: -34px;
                margin-left: 10px;">CDSCO Registration</a>
                <i class="fa fa-angle-right" style="font-size:20px; margin-left: 10px; margin-top: 12px;"></i> <a href="https://sunconsultants.co.in/fmcs-certification-consultants" style="margin-top: -34px;
                margin-left: 10px;">BIS Mark (ISI license) for <br> Foreign Manufactures</a>
                <i class="fa fa-angle-right" style="font-size:20px; margin-left: 10px; margin-top: 8px;"></i> <a href="https://sunconsultants.co.in/isi-mark-registration-certification" style="margin-top: -34px;
                margin-left: 10px;">ISI MARK (BIS) for <br> Indian Manufacturers</a>
             <i class="fa fa-angle-right" style="font-size:20px; margin-left: 10px; margin-top: 8px;"></i>   <a href="https://sunconsultants.co.in/epr-certification-consultants" style="margin-top: -34px;
             margin-left: 10px;">EPR Registration</a>
                <i class="fa fa-angle-right" style="font-size:20px; margin-left: 10px; margin-top: 8px;"></i><a href="https://sunconsultants.co.in/epr-certification-consultants" style="margin-top: -34px;
                margin-left: 10px;">Battery Waste Management</a>
              <i class="fa fa-angle-right" style="font-size:20px; margin-left: 10px; margin-top: 8px;"></i>  <a href="https://sunconsultants.co.in/lmpc-certification-consultants" style="margin-top: -34px;
              margin-left: 10px;">LMPC Registration </a>


              </li>
              <li>
                <i class="fa fa-angle-right" style="font-size:20px; margin-left: 10px; margin-top: 8px;"></i>   <a href="https://sunconsultants.co.in/plastic-waste-management-registration" style="margin-top: -34px;
                margin-left: 10px;">Plastic Waste Management </a>
               <i class="fa fa-angle-right" style="font-size:20px; margin-left: 10px; margin-top: 8px;"></i> <a href="https://sunconsultants.co.in/legal-metrology-certification-consultants" style="margin-top: -34px;
               margin-left: 10px;">LEGAL METROLOGY</a>
               <i class="fa fa-angle-right" style="font-size:20px; margin-left: 10px; margin-top: 8px;"></i> <a href="https://sunconsultants.co.in/bis-registration-certification" style="margin-top: -34px;
               margin-left: 10px;">BIS Certification</a>
               <i class="fa fa-angle-right" style="font-size:20px; margin-left: 10px; margin-top: 8px;"></i> <a href="https://sunconsultants.co.in/bis-(crs)-registration-for-elect" style="margin-top: -34px;
               margin-left: 10px;">CRS Registration (BIS)</a>
               <i class="fa fa-angle-right" style="font-size:20px; margin-left: 10px; margin-top: 8px;"></i> <a href="https://sunconsultants.co.in/peso-certification-consultants" style="margin-top: -34px;
               margin-left: 10px;">PESO APPROVAL</a>
               <i class="fa fa-angle-right" style="font-size:20px; margin-left: 10px; margin-top: 8px;"></i> <a href="https://sunconsultants.co.in/tec-certification-consultants" style="margin-top: -34px;
               margin-left: 10px;">TEC </a>
               <i class="fa fa-angle-right" style="font-size:20px; margin-left: 10px; margin-top: 8px;"></i> <a href="https://sunconsultants.co.in/wpc-certification-consultants" style="margin-top: -34px;
               margin-left: 10px;">WPC</a>
              </li>
              <li s>
                <i class="fa fa-angle-right" style="font-size:20px; margin-left: 20px; margin-top: 8px;"></i> <a href="https://sunconsultants.co.in/rohs-certification-consultants"style="margin-top: -34px;
                margin-left: 20px;">ROHS</a>
                <i class="fa fa-angle-right" style="font-size:20px; margin-left: 20px; margin-top: 8px;"></i> <a href="https://sunconsultants.co.in/bee-registration-certification"style="margin-top: -34px;
                margin-left: 20px;">BEE</a>
                 <i class="fa fa-angle-right" style="font-size:20px; margin-left: 20px; margin-top: 8px;"></i><a href="https://sunconsultants.co.in/ce-certification-consultants" style="margin-top: -34px;
                margin-left: 20px;">CE CERTIFICATION</a>
                <i class="fa fa-angle-right" style="font-size:20px; margin-left: 20px; margin-top: 8px;"></i> <a href="https://sunconsultants.co.in/emi-emc-certification-consultants" style="margin-top: -34px;
                margin-left: 20px;">EMI/EMC</a>
                <i class="fa fa-angle-right" style="font-size:20px; margin-left: 20px; margin-top: 8px;"></i> <a href="https://sunconsultants.co.in/cb-certification-consultants" style="margin-top: -34px;
                margin-left: 20px;">CB CERTIFICATION</a>
                <a href=""></a>
                <a href=""></a>
                <a href=""></a>
                <a href=""></a>
            </li>
            
            </ul>
          </li>

      
          

         
           

    
              <li class="dropdown"><a href="#"><span>UPDATES</span> <i class="bi bi-chevron-down dropdown-indicator"></i></a>
                <ul style="width: 270px;">
                  <li><i class="fa fa-angle-right" style="font-size:20px; margin-left: 10px; margin-top: 8px;"></i><a href=""style="margin-top: -34px;
                    margin-left: 10px;">Latest Notifications</a></li>
                  <li><i class="fa fa-angle-right" style="font-size:20px; margin-left: 10px; margin-top: 8px;"></i><a href="https://sunconsultants.co.in"style="margin-top: -34px;
                    margin-left: 10px;">News and Updates  </a></li>
                  <li><i class="fa fa-angle-right" style="font-size:20px; margin-left: 10px; margin-top: 8px;"></i><a href="https://sunconsultants.co.in"style="margin-top: -34px;
                    margin-left: 10px;">Blogs </a></li>
                  </ul>
                  </li>
          <li><a href="/contact-us">CONTACT US</a></li>

          <!-- <li class="dropdown"><a href="#"><span>Drop Down</span> <i class="bi bi-chevron-down dropdown-indicator"></i></a>
            <ul>
              <li><a href="#">Drop Down 1</a></li>
              <li class="dropdown"><a href="#"><span>Deep Drop Down</span> <i class="bi bi-chevron-down dropdown-indicator"></i></a>
                <ul>
                  <li><a href="#">Deep Drop Down 1</a></li>
                  <li><a href="#">Deep Drop Down 2</a></li>
                  <li><a href="#">Deep Drop Down 3</a></li>
                  <li><a href="#">Deep Drop Down 4</a></li>
                  <li><a href="#">Deep Drop Down 5</a></li>
                </ul>
              </li>
              <li><a href="#">Drop Down 2</a></li>
              <li><a href="#">Drop Down 3</a></li>
              <li><a href="#">Drop Down 4</a></li>
            </ul>
          </li> -->
          
          
          <li class="dropdown" id="8"><a href="#"><span>FAQ'S</span> <i class="bi bi-chevron-down dropdown-indicator"></i></a>
            <ul style="width: 270px;">
              <li><i class="fa fa-angle-right" style="font-size:20px; margin-left: 10px; margin-top: 8px;"></i><a href="https://sunconsultants.co.in/bis-licence-consultants" style="margin-top: -34px;
                margin-left: 20px;">BIS Licence</a></li>
              <li><i class="fa fa-angle-right" style="font-size:20px; margin-left: 10px; margin-top: 8px;"></i><a href="https://sunconsultants.co.in" style="margin-top: -34px;
                margin-left: 20px;">BIS Registration </a></li>
              <li><i class="fa fa-angle-right" style="font-size:20px; margin-left: 10px; margin-top: 8px;"></i><a href="https://sunconsultants.co.in" style="margin-top: -34px;
                margin-left: 20px;">CDSCO Licence </a></li>
              <li><i class="fa fa-angle-right" style="font-size:20px; margin-left: 10px; margin-top: 8px;"></i><a href="https://sunconsultants.co.in/cdsco-registration-certification" style="margin-top: -34px;
                margin-left: 20px;">CDSCO Registration  </a></li>
              <li><i class="fa fa-angle-right" style="font-size:20px; margin-left: 10px; margin-top: 8px;"></i><a href="https://sunconsultants.co.in" style="margin-top: -34px;
                margin-left: 20px;">Foreign Manufacturer BIS  </a></li>
              </ul>
              </li>
          <li class="dropdown"><a href="https://sunconsultants.co.in"><span>PAY</span> </a>
            <!-- <ul>
              <li><a href="#"></a></li>
              </ul>
        </ul> -->
        </li>
        </ul>
        
      </nav>
      <!-- .navbar -->

      <i class="mobile-nav-toggle mobile-nav-show bi bi-list"></i>
      <i class="mobile-nav-toggle mobile-nav-hide d-none bi bi-x"></i>
      
    </div>
    
  </header>
  
  <div class="col-md-12 pt-3">
   

    
</div>
</body></html>